import { useLocation } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { useTheme } from "./ThemeProvider";
import {
  LayoutDashboard,
  FileText,
  PlusCircle,
  Sun,
  Moon,
  Clapperboard,
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const navItems = [
  { icon: FileText, label: "All Requests", href: "/" },
  { icon: PlusCircle, label: "New Request", href: "/new" },
];

export default function Sidebar() {
  const [location, navigate] = useHashLocation();
  const { theme, toggle } = useTheme();

  return (
    <TooltipProvider delayDuration={200}>
      <aside className="sidebar relative z-20 flex flex-col items-center w-16 h-screen py-5 gap-2 flex-shrink-0">
        {/* Logo */}
        <div className="mb-4 flex items-center justify-center w-10 h-10 rounded-2xl" style={{ background: "linear-gradient(135deg, #4a7cf7, #7c6ff7)" }}>
          <Clapperboard size={20} color="white" strokeWidth={2} />
        </div>

        <div className="w-8 h-px bg-white/20 mb-2" />

        {/* Nav */}
        <nav className="flex flex-col items-center gap-2 flex-1">
          {navItems.map(({ icon: Icon, label, href }) => {
            const isActive = location === href;
            return (
              <Tooltip key={href}>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => navigate(href)}
                    data-testid={`nav-${label.toLowerCase().replace(/\s+/g, "-")}`}
                    className={`
                      w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-200
                      ${isActive
                        ? "shadow-lg text-white"
                        : "text-[var(--text-secondary)] hover:text-[var(--accent-blue)] hover:bg-white/20"
                      }
                    `}
                    style={isActive ? { background: "linear-gradient(135deg, #4a7cf7, #7c6ff7)", boxShadow: "0 4px 16px rgba(74,124,247,0.4)" } : {}}
                  >
                    <Icon size={18} />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="right" className="glass text-sm font-medium">
                  {label}
                </TooltipContent>
              </Tooltip>
            );
          })}
        </nav>

        {/* Bottom: theme toggle */}
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={toggle}
              data-testid="theme-toggle"
              className="w-10 h-10 rounded-xl flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--accent-blue)] hover:bg-white/20 transition-all duration-200"
            >
              {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
            </button>
          </TooltipTrigger>
          <TooltipContent side="right" className="glass text-sm font-medium">
            {theme === "dark" ? "Light mode" : "Dark mode"}
          </TooltipContent>
        </Tooltip>

        {/* User avatar */}
        <div
          className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-semibold mt-1"
          style={{ background: "linear-gradient(135deg, #f472b6, #7c6ff7)" }}
        >
          S
        </div>
      </aside>
    </TooltipProvider>
  );
}
