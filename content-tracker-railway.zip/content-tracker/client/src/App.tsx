import { Switch, Route, Router, Redirect } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import Sidebar from "./components/Sidebar";
import Requests from "./pages/Requests";
import NewRequest from "./pages/NewRequest";
import NotFound from "./pages/not-found";
import ThemeProvider from "./components/ThemeProvider";

function AppShell() {
  return (
    <div className="relative flex h-screen overflow-hidden">
      {/* Animated background orbs */}
      <div className="orb orb-1" />
      <div className="orb orb-2" />
      <div className="orb orb-3" />

      {/* Sidebar */}
      <Sidebar />

      {/* Main content */}
      <main className="relative z-10 flex-1 overflow-y-auto overscroll-contain">
        <Router hook={useHashLocation}>
          <Switch>
            {/* Landing page = All Requests + Dashboard below */}
            <Route path="/" component={Requests} />
            <Route path="/requests" component={Requests} />
            <Route path="/new" component={NewRequest} />
            <Route component={NotFound} />
          </Switch>
        </Router>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <AppShell />
        <Toaster />
      </QueryClientProvider>
    </ThemeProvider>
  );
}
