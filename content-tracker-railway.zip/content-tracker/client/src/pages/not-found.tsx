import { useHashLocation } from "wouter/use-hash-location";

export default function NotFound() {
  const [, navigate] = useHashLocation();
  return (
    <div className="flex flex-col items-center justify-center h-screen gap-4">
      <div className="glass rounded-2xl p-10 text-center border max-w-sm">
        <p className="text-5xl font-bold gradient-text mb-3">404</p>
        <p className="text-sm" style={{ color: "var(--text-secondary)" }}>Page not found</p>
        <button
          onClick={() => navigate("/")}
          className="mt-6 px-6 py-2.5 rounded-xl text-sm font-semibold text-white"
          style={{ background: "linear-gradient(135deg, #4a7cf7, #7c6ff7)" }}
        >
          Go to Dashboard
        </button>
      </div>
    </div>
  );
}
