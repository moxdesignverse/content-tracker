import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { ContentRequest } from "@shared/schema";
import { useState } from "react";
import { useHashLocation } from "wouter/use-hash-location";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PlusCircle } from "lucide-react";

const CONTENT_TYPES = [
  "Promotional Video", "Explainer Video", "Social Reel", "Motion Graphics",
  "Character Animation", "Brand Video", "Testimonial / Case Study",
  "Animated Infographic", "AI Video", "Website Video", "Conversion Video",
  "Podcast Visual", "Logo Animation", "Cinematic Advert", "Other",
];

const REQUESTORS = ["Abhyuday", "Shubhra", "Ruchita", "Abhishek", "Vipin", "Other"];
const ASSIGNEES = ["Vipin", "Yeshveer", "Neeta", "Other"];

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--text-muted)" }}>
        {label} {required && <span style={{ color: "#f472b6" }}>*</span>}
      </Label>
      {children}
    </div>
  );
}

const inputStyle = {
  background: "rgba(255,255,255,0.35)",
  borderColor: "var(--glass-border)",
  color: "var(--text-primary)",
  borderRadius: "12px",
};

/**
 * Select + optional custom text input when "Other" is chosen.
 *
 * Uses a separate `showCustom` boolean so the text box always appears
 * immediately when the user picks "Other", regardless of what value
 * the parent stores.
 */
function SelectWithOther({
  value,
  onChange,
  options,
  placeholder,
  testId,
}: {
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
  testId?: string;
}) {
  // A value that isn't in the known options list (excluding "Other") = custom
  const knownOptions = options.filter(o => o !== "Other");
  const isCustomValue = value !== "" && !knownOptions.includes(value);

  // showCustom is true when the dropdown is showing "Other" or the stored
  // value is already a custom string
  const [showCustom, setShowCustom] = useState(isCustomValue);

  const selectVal = isCustomValue || showCustom ? "Other" : value;

  return (
    <div className="space-y-2">
      <Select
        value={selectVal}
        onValueChange={(v) => {
          if (v === "Other") {
            setShowCustom(true);
            // Keep the existing custom value if there already is one,
            // otherwise clear so the user can type a fresh name
            if (!isCustomValue) onChange("");
          } else {
            setShowCustom(false);
            onChange(v);
          }
        }}
      >
        <SelectTrigger style={inputStyle} data-testid={testId}>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent className="glass-strong rounded-xl">
          {options.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
        </SelectContent>
      </Select>

      {showCustom && (
        <Input
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder="Type custom name…"
          style={inputStyle}
          className="text-sm"
          autoFocus
          data-testid={testId ? `${testId}-custom` : undefined}
        />
      )}
    </div>
  );
}

// Exported for use in Requests.tsx inline form
export { SelectWithOther, REQUESTORS, ASSIGNEES, CONTENT_TYPES, inputStyle, Field };

export default function NewRequest() {
  const [, navigate] = useHashLocation();
  const qc = useQueryClient();
  const { toast } = useToast();

  const { data: requests = [] } = useQuery<ContentRequest[]>({
    queryKey: ["/api/requests"],
    queryFn: () => apiRequest("GET", "/api/requests").then(r => r.json()),
  });

  const nextId = (() => {
    const nums = requests.map(r => parseInt(r.requestId.replace("CCR-", ""))).filter(n => !isNaN(n));
    const max = nums.length > 0 ? Math.max(...nums) : 0;
    return `CCR-${String(max + 1).padStart(3, "0")}`;
  })();

  const [form, setForm] = useState({
    requestId: nextId,
    requestorName: "",
    projectTitle: "",
    contentType: "",
    quantity: 1,
    projectBrief: "",
    referenceMoodBoard: "",
    targetAudience: "",
    keyMessage: "",
    dateOfSubmission: new Date().toISOString().split("T")[0],
    workStartDate: "",
    completedDate: "",
    deadline: "",
    durationSpecs: "",
    durationMins: "",
    priorityLevel: "High",
    status: "Pending",
    completedBy: "Vipin",
    scriptLink: "",
    videoLink: "",
    youtubeLink: "",
    notes: "",
  });

  const set = (key: string) => (e: any) => setForm(f => ({ ...f, [key]: e.target ? e.target.value : e }));
  const setVal = (key: string) => (v: string) => setForm(f => ({ ...f, [key]: v }));

  const mutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/requests", data).then(r => r.json()),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/requests"] });
      toast({ title: "Request submitted", description: `${form.requestId} has been created.` });
      navigate("/requests");
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.requestorName || !form.projectTitle || !form.contentType) {
      toast({ title: "Missing fields", description: "Requestor, Project Title and Content Type are required.", variant: "destructive" });
      return;
    }
    mutation.mutate({ ...form, quantity: Number(form.quantity), durationMins: form.durationMins ? Number(form.durationMins) : null });
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="fade-in mb-6">
        <h1 className="text-xl font-bold gradient-text">New Content Request</h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--text-secondary)" }}>
          Auto-assigned ID: <span className="font-mono font-semibold" style={{ color: "var(--accent-blue)" }}>{nextId}</span>
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Identity */}
        <div className="glass rounded-2xl p-5 border fade-in fade-in-delay-1">
          <h2 className="text-sm font-semibold mb-4" style={{ color: "var(--text-primary)" }}>Request Identity</h2>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Request ID">
              <Input value={form.requestId} onChange={set("requestId")} style={inputStyle} className="font-mono text-sm" data-testid="input-request-id" />
            </Field>
            <Field label="Requestor Name" required>
              <SelectWithOther
                value={form.requestorName}
                onChange={setVal("requestorName")}
                options={REQUESTORS}
                placeholder="Select requestor"
                testId="select-requestor"
              />
            </Field>
            <Field label="Project Title" required>
              <Input value={form.projectTitle} onChange={set("projectTitle")} placeholder="Name/title of project or campaign" style={inputStyle} className="text-sm" data-testid="input-project-title" />
            </Field>
            <Field label="Content Type" required>
              <SelectWithOther
                value={form.contentType}
                onChange={setVal("contentType")}
                options={CONTENT_TYPES}
                placeholder="Select type"
                testId="select-content-type"
              />
            </Field>
            <Field label="Quantity">
              <Input type="number" min={1} value={form.quantity} onChange={set("quantity")} style={inputStyle} className="text-sm" data-testid="input-quantity" />
            </Field>
            <Field label="Duration / Specs">
              <Input value={form.durationSpecs} onChange={set("durationSpecs")} placeholder="e.g. 45–60 seconds, 16:9" style={inputStyle} className="text-sm" data-testid="input-duration-specs" />
            </Field>
          </div>
        </div>

        {/* Brief */}
        <div className="glass rounded-2xl p-5 border fade-in fade-in-delay-2">
          <h2 className="text-sm font-semibold mb-4" style={{ color: "var(--text-primary)" }}>Creative Brief</h2>
          <div className="space-y-4">
            <Field label="Project Brief">
              <Textarea value={form.projectBrief} onChange={set("projectBrief")} placeholder="Brief overview of what the content should convey…" style={{ ...inputStyle, minHeight: "90px" }} className="text-sm resize-none" data-testid="input-project-brief" />
            </Field>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Target Audience">
                <Textarea value={form.targetAudience} onChange={set("targetAudience")} placeholder="Who is this for? Age range, profession, etc." style={{ ...inputStyle, minHeight: "70px" }} className="text-sm resize-none" data-testid="input-target-audience" />
              </Field>
              <Field label="Key Message">
                <Textarea value={form.keyMessage} onChange={set("keyMessage")} placeholder="Main message or emotion you want to convey…" style={{ ...inputStyle, minHeight: "70px" }} className="text-sm resize-none" data-testid="input-key-message" />
              </Field>
            </div>
            <Field label="Reference / Mood Board">
              <Textarea value={form.referenceMoodBoard} onChange={set("referenceMoodBoard")} placeholder="Links to references, competitor examples, mood board ideas…" style={{ ...inputStyle, minHeight: "70px" }} className="text-sm resize-none" data-testid="input-reference" />
            </Field>
          </div>
        </div>

        {/* Timeline */}
        <div className="glass rounded-2xl p-5 border fade-in fade-in-delay-3">
          <h2 className="text-sm font-semibold mb-4" style={{ color: "var(--text-primary)" }}>Timeline & Priority</h2>
          <div className="grid grid-cols-3 gap-4">
            <Field label="Date of Submission">
              <Input type="date" value={form.dateOfSubmission} onChange={set("dateOfSubmission")} style={inputStyle} className="text-sm" data-testid="input-submission-date" />
            </Field>
            <Field label="Work Start Date">
              <Input type="date" value={form.workStartDate} onChange={set("workStartDate")} style={inputStyle} className="text-sm" data-testid="input-start-date" />
            </Field>
            <Field label="Deadline">
              <Input type="date" value={form.deadline} onChange={set("deadline")} style={inputStyle} className="text-sm" data-testid="input-deadline" />
            </Field>
            <Field label="Priority Level">
              <Select value={form.priorityLevel} onValueChange={setVal("priorityLevel")}>
                <SelectTrigger style={inputStyle} data-testid="select-priority">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="glass-strong rounded-xl">
                  {["High", "Moderate", "Medium", "Low"].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Status">
              <Select value={form.status} onValueChange={setVal("status")}>
                <SelectTrigger style={inputStyle} data-testid="select-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="glass-strong rounded-xl">
                  {["Pending", "In Progress", "In Review", "Pending Production", "Completed", "Completed (On Hold)"].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Assigned To">
              <SelectWithOther
                value={form.completedBy}
                onChange={setVal("completedBy")}
                options={ASSIGNEES}
                placeholder="Select assignee"
                testId="select-assigned-to"
              />
            </Field>
          </div>
        </div>

        {/* Links & extras */}
        <div className="glass rounded-2xl p-5 border fade-in fade-in-delay-4">
          <h2 className="text-sm font-semibold mb-4" style={{ color: "var(--text-primary)" }}>Links & Notes</h2>
          <div className="grid grid-cols-3 gap-4">
            <Field label="Script Link">
              <Input value={form.scriptLink} onChange={set("scriptLink")} placeholder="https://… or file name" style={inputStyle} className="text-sm" data-testid="input-script-link" />
            </Field>
            <Field label="Video Link">
              <Input value={form.videoLink} onChange={set("videoLink")} placeholder="https://drive.google.com/…" style={inputStyle} className="text-sm" data-testid="input-video-link" />
            </Field>
            <Field label="YouTube Link">
              <Input value={form.youtubeLink} onChange={set("youtubeLink")} placeholder="https://youtube.com/…" style={inputStyle} className="text-sm" data-testid="input-youtube-link" />
            </Field>
            <Field label="Duration (mins)">
              <Input type="number" step="0.01" value={form.durationMins} onChange={set("durationMins")} placeholder="e.g. 1.5" style={inputStyle} className="text-sm" data-testid="input-duration-mins" />
            </Field>
          </div>
          <div className="mt-4">
            <Field label="Additional Notes">
              <Textarea value={form.notes} onChange={set("notes")} placeholder="Any other context, brand guidelines, special instructions…" style={{ ...inputStyle, minHeight: "70px" }} className="text-sm resize-none" data-testid="input-notes" />
            </Field>
          </div>
        </div>

        {/* Submit */}
        <div className="flex gap-3 pb-6">
          <Button
            type="submit"
            disabled={mutation.isPending}
            className="flex-1 h-11 rounded-xl text-white font-semibold text-sm flex items-center justify-center gap-2"
            style={{ background: "linear-gradient(135deg, #4a7cf7, #7c6ff7)", boxShadow: "0 4px 16px rgba(74,124,247,0.35)" }}
            data-testid="button-submit-request"
          >
            <PlusCircle size={16} />
            {mutation.isPending ? "Submitting…" : "Submit Request"}
          </Button>
          <Button
            type="button"
            variant="ghost"
            onClick={() => navigate("/requests")}
            className="h-11 px-6 rounded-xl text-sm"
            style={{ background: "rgba(255,255,255,0.3)", border: "1px solid var(--glass-border)" }}
            data-testid="button-cancel"
          >
            Cancel
          </Button>
        </div>
      </form>
    </div>
  );
}
