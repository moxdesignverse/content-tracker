import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { ContentRequest } from "@shared/schema";
import { useState, useMemo } from "react";
import { StatusBadge, PriorityBadge } from "./Dashboard";
import DashboardContent from "./Dashboard";
import {
  Search, Edit2, Trash2, ExternalLink, X, SlidersHorizontal,
  PlusCircle, ChevronUp, Link2, AlertTriangle, FileText,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { SelectWithOther, REQUESTORS, ASSIGNEES, CONTENT_TYPES, inputStyle, Field } from "./NewRequest";

const STATUS_OPTIONS = ["All", "Completed", "Pending Production", "In Progress", "In Review", "Completed (On Hold)", "Pending"];
const PRIORITY_OPTIONS = ["All", "High", "Moderate", "Medium", "Low"];
const REQUESTER_OPTIONS = ["All", "Abhyuday", "Shubhra", "Ruchita", "Abhishek", "Vipin"];

// ─── Inline New Request Form ──────────────────────────────────────────────────
function InlineNewRequest({
  requests,
  onSuccess,
  onCancel,
}: {
  requests: ContentRequest[];
  onSuccess: () => void;
  onCancel: () => void;
}) {
  const qc = useQueryClient();
  const { toast } = useToast();

  const nextId = (() => {
    const nums = requests.map(r => parseInt(r.requestId.replace("CCR-", ""))).filter(n => !isNaN(n));
    const max = nums.length > 0 ? Math.max(...nums) : 0;
    return `CCR-${String(max + 1).padStart(3, "0")}`;
  })();

  const [form, setForm] = useState({
    requestId: nextId,
    requestorName: "",
    projectTitle: "",
    contentType: "",
    quantity: 1,
    projectBrief: "",
    referenceMoodBoard: "",
    targetAudience: "",
    keyMessage: "",
    dateOfSubmission: new Date().toISOString().split("T")[0],
    workStartDate: "",
    completedDate: "",
    deadline: "",
    durationSpecs: "",
    durationMins: "",
    priorityLevel: "High",
    status: "Pending",
    completedBy: "Vipin",
    scriptLink: "",
    videoLink: "",
    youtubeLink: "",
    notes: "",
  });

  const set = (key: string) => (e: any) => setForm(f => ({ ...f, [key]: e.target ? e.target.value : e }));
  const setVal = (key: string) => (v: string) => setForm(f => ({ ...f, [key]: v }));

  const mutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/requests", data).then(r => r.json()),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/requests"] });
      toast({ title: "Request created", description: `${form.requestId} added successfully.` });
      onSuccess();
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.requestorName || !form.projectTitle || !form.contentType) {
      toast({ title: "Missing fields", description: "Requestor, Project Title and Content Type are required.", variant: "destructive" });
      return;
    }
    mutation.mutate({ ...form, quantity: Number(form.quantity), durationMins: form.durationMins ? Number(form.durationMins) : null });
  };

  return (
    <div className="glass rounded-2xl border overflow-hidden fade-in" style={{ borderColor: "var(--glass-border)" }}>
      {/* Form header */}
      <div className="flex items-center justify-between px-6 py-4" style={{ background: "rgba(74,124,247,0.06)", borderBottom: "1px solid rgba(150,170,220,0.15)" }}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: "linear-gradient(135deg, #4a7cf7, #7c6ff7)" }}>
            <PlusCircle size={15} color="white" />
          </div>
          <div>
            <p className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>New Content Request</p>
            <p className="text-xs" style={{ color: "var(--text-muted)" }}>
              Auto-assigned: <span className="font-mono font-semibold" style={{ color: "var(--accent-blue)" }}>{nextId}</span>
            </p>
          </div>
        </div>
        <button onClick={onCancel} className="w-7 h-7 rounded-lg flex items-center justify-center transition-all hover:bg-white/20" style={{ color: "var(--text-muted)" }}>
          <ChevronUp size={16} />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        {/* Row 1: Identity */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "var(--text-muted)" }}>Request Identity</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <Field label="Request ID">
              <Input value={form.requestId} onChange={set("requestId")} style={inputStyle} className="font-mono text-sm" />
            </Field>
            <Field label="Requestor Name" required>
              <SelectWithOther value={form.requestorName} onChange={setVal("requestorName")} options={REQUESTORS} placeholder="Select requestor" testId="inline-select-requestor" />
            </Field>
            <Field label="Project Title" required>
              <Input value={form.projectTitle} onChange={set("projectTitle")} placeholder="Name/title of project or campaign" style={inputStyle} className="text-sm" />
            </Field>
            <Field label="Content Type" required>
              <SelectWithOther value={form.contentType} onChange={setVal("contentType")} options={CONTENT_TYPES} placeholder="Select type" testId="inline-select-content-type" />
            </Field>
            <Field label="Quantity">
              <Input type="number" min={1} value={form.quantity} onChange={set("quantity")} style={inputStyle} className="text-sm" />
            </Field>
            <Field label="Duration / Specs">
              <Input value={form.durationSpecs} onChange={set("durationSpecs")} placeholder="e.g. 45–60 sec, 16:9" style={inputStyle} className="text-sm" />
            </Field>
          </div>
        </div>

        {/* Row 2: Brief */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "var(--text-muted)" }}>Creative Brief</p>
          <div className="space-y-3">
            <Field label="Project Brief">
              <Textarea value={form.projectBrief} onChange={set("projectBrief")} placeholder="Brief overview of what the content should convey…" style={{ ...inputStyle, minHeight: "80px" }} className="text-sm resize-none" />
            </Field>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Target Audience">
                <Textarea value={form.targetAudience} onChange={set("targetAudience")} placeholder="Who is this for?" style={{ ...inputStyle, minHeight: "64px" }} className="text-sm resize-none" />
              </Field>
              <Field label="Key Message">
                <Textarea value={form.keyMessage} onChange={set("keyMessage")} placeholder="Main message or emotion…" style={{ ...inputStyle, minHeight: "64px" }} className="text-sm resize-none" />
              </Field>
            </div>
            <Field label="Reference / Mood Board">
              <Textarea value={form.referenceMoodBoard} onChange={set("referenceMoodBoard")} placeholder="Links to references, competitor examples, mood board ideas…" style={{ ...inputStyle, minHeight: "64px" }} className="text-sm resize-none" />
            </Field>
          </div>
        </div>

        {/* Row 3: Timeline */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "var(--text-muted)" }}>Timeline & Priority</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <Field label="Date of Submission">
              <Input type="date" value={form.dateOfSubmission} onChange={set("dateOfSubmission")} style={inputStyle} className="text-sm" />
            </Field>
            <Field label="Work Start Date">
              <Input type="date" value={form.workStartDate} onChange={set("workStartDate")} style={inputStyle} className="text-sm" />
            </Field>
            <Field label="Deadline">
              <Input type="date" value={form.deadline} onChange={set("deadline")} style={inputStyle} className="text-sm" />
            </Field>
            <Field label="Priority Level">
              <Select value={form.priorityLevel} onValueChange={setVal("priorityLevel")}>
                <SelectTrigger style={inputStyle}><SelectValue /></SelectTrigger>
                <SelectContent className="glass-strong rounded-xl">
                  {["High", "Moderate", "Medium", "Low"].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Status">
              <Select value={form.status} onValueChange={setVal("status")}>
                <SelectTrigger style={inputStyle}><SelectValue /></SelectTrigger>
                <SelectContent className="glass-strong rounded-xl">
                  {["Pending", "In Progress", "In Review", "Pending Production", "Completed", "Completed (On Hold)"].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Assigned To">
              <SelectWithOther value={form.completedBy} onChange={setVal("completedBy")} options={ASSIGNEES} placeholder="Select assignee" testId="inline-select-assigned" />
            </Field>
          </div>
        </div>

        {/* Row 4: Links */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "var(--text-muted)" }}>Links & Notes</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Field label="Script Link">
              <Input value={form.scriptLink} onChange={set("scriptLink")} placeholder="https://…" style={inputStyle} className="text-sm" />
            </Field>
            <Field label="Video Link">
              <Input value={form.videoLink} onChange={set("videoLink")} placeholder="https://drive.google.com/…" style={inputStyle} className="text-sm" />
            </Field>
            <Field label="YouTube Link">
              <Input value={form.youtubeLink} onChange={set("youtubeLink")} placeholder="https://youtube.com/…" style={inputStyle} className="text-sm" />
            </Field>
            <Field label="Duration (mins)">
              <Input type="number" step="0.01" value={form.durationMins} onChange={set("durationMins")} placeholder="e.g. 1.5" style={inputStyle} className="text-sm" />
            </Field>
          </div>
          <div className="mt-3">
            <Field label="Additional Notes">
              <Textarea value={form.notes} onChange={set("notes")} placeholder="Brand guidelines, special instructions…" style={{ ...inputStyle, minHeight: "60px" }} className="text-sm resize-none" />
            </Field>
          </div>
        </div>

        {/* Submit row */}
        <div className="flex gap-3 pt-2">
          <Button
            type="submit"
            disabled={mutation.isPending}
            className="flex-1 h-10 rounded-xl text-white font-semibold text-sm flex items-center justify-center gap-2"
            style={{ background: "linear-gradient(135deg, #4a7cf7, #7c6ff7)", boxShadow: "0 4px 16px rgba(74,124,247,0.3)" }}
            data-testid="button-inline-submit"
          >
            <PlusCircle size={15} />
            {mutation.isPending ? "Submitting…" : "Submit Request"}
          </Button>
          <Button type="button" variant="ghost" onClick={onCancel} className="h-10 px-5 rounded-xl text-sm" style={{ background: "rgba(255,255,255,0.25)", border: "1px solid var(--glass-border)" }}>
            Collapse
          </Button>
        </div>
      </form>
    </div>
  );
}

// ─── Delete Confirm Dialog ────────────────────────────────────────────────────
function DeleteConfirmDialog({
  request,
  onConfirm,
  onCancel,
  isPending,
}: {
  request: ContentRequest;
  onConfirm: () => void;
  onCancel: () => void;
  isPending: boolean;
}) {
  return (
    <DialogContent className="glass-strong max-w-sm rounded-2xl border" style={{ borderColor: "var(--glass-border)" }}>
      <DialogHeader>
        <div className="flex items-center gap-3 mb-1">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "rgba(239,68,68,0.12)" }}>
            <AlertTriangle size={18} style={{ color: "#dc2626" }} />
          </div>
          <DialogTitle className="text-base font-bold" style={{ color: "var(--text-primary)" }}>Delete Request</DialogTitle>
        </div>
      </DialogHeader>
      <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
        Are you sure you want to permanently delete{" "}
        <span className="font-semibold font-mono" style={{ color: "var(--accent-blue)" }}>{request.requestId}</span>
        {" "}— <span className="font-medium">{request.projectTitle || request.contentType}</span>?
        This cannot be undone.
      </p>
      <div className="flex gap-3 mt-4">
        <Button
          onClick={onConfirm}
          disabled={isPending}
          className="flex-1 h-10 rounded-xl text-white font-semibold text-sm"
          style={{ background: "linear-gradient(135deg, #ef4444, #dc2626)" }}
          data-testid="button-confirm-delete"
        >
          {isPending ? "Deleting…" : "Yes, Delete"}
        </Button>
        <Button variant="ghost" onClick={onCancel} className="h-10 px-4 rounded-xl text-sm" style={{ background: "rgba(255,255,255,0.25)", border: "1px solid var(--glass-border)" }}>
          Cancel
        </Button>
      </div>
    </DialogContent>
  );
}

// ─── Edit Dialog ──────────────────────────────────────────────────────────────
function EditDialog({ request, onClose }: { request: ContentRequest; onClose: () => void }) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [form, setForm] = useState({ ...request });

  const mutation = useMutation({
    mutationFn: (data: Partial<ContentRequest>) =>
      apiRequest("PATCH", `/api/requests/${request.id}`, data).then(r => r.json()),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/requests"] });
      toast({ title: "Updated", description: `${request.requestId} has been updated.` });
      onClose();
    },
    onError: () => toast({ title: "Error", description: "Failed to update.", variant: "destructive" }),
  });

  const setVal = (key: keyof ContentRequest) => (v: string) => setForm(f => ({ ...f, [key]: v }));

  const textField = (key: keyof ContentRequest, label: string, type: "input" | "textarea" = "input") => (
    <div key={String(key)} className="space-y-1">
      <Label className="text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--text-muted)" }}>{label}</Label>
      {type === "textarea" ? (
        <Textarea
          value={(form[key] as string) || ""}
          onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
          className="glass text-sm min-h-[70px] rounded-xl border resize-none"
          style={{ background: "rgba(255,255,255,0.3)", borderColor: "var(--glass-border)", color: "var(--text-primary)" }}
        />
      ) : (
        <Input
          value={(form[key] as string) || ""}
          onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
          className="glass text-sm rounded-xl"
          style={{ background: "rgba(255,255,255,0.3)", borderColor: "var(--glass-border)", color: "var(--text-primary)" }}
        />
      )}
    </div>
  );

  const selectField = (key: keyof ContentRequest, label: string, options: string[]) => (
    <div key={String(key)} className="space-y-1">
      <Label className="text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--text-muted)" }}>{label}</Label>
      <Select value={(form[key] as string) || ""} onValueChange={v => setForm(f => ({ ...f, [key]: v }))}>
        <SelectTrigger className="glass text-sm rounded-xl" style={{ background: "rgba(255,255,255,0.3)", borderColor: "var(--glass-border)", color: "var(--text-primary)" }}>
          <SelectValue />
        </SelectTrigger>
        <SelectContent className="glass-strong rounded-xl">
          {options.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
        </SelectContent>
      </Select>
    </div>
  );

  const selectWithOtherField = (key: keyof ContentRequest, label: string, options: string[]) => (
    <div key={String(key)} className="space-y-1">
      <Label className="text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--text-muted)" }}>{label}</Label>
      <SelectWithOther
        value={(form[key] as string) || ""}
        onChange={setVal(key)}
        options={options}
        placeholder={`Select ${label.toLowerCase()}`}
      />
    </div>
  );

  return (
    <DialogContent className="glass-strong max-w-2xl rounded-2xl border max-h-[85vh] overflow-y-auto" style={{ borderColor: "var(--glass-border)" }}>
      <DialogHeader>
        <DialogTitle className="gradient-text text-base font-bold">Edit {request.requestId}</DialogTitle>
      </DialogHeader>
      <div className="grid grid-cols-2 gap-4 mt-2">
        {selectWithOtherField("requestorName", "Requestor", REQUESTORS)}
        {textField("projectTitle", "Project Title")}
        {selectWithOtherField("contentType", "Content Type", CONTENT_TYPES)}
        {textField("quantity", "Quantity")}
        {selectField("status", "Status", ["Pending", "In Progress", "In Review", "Pending Production", "Completed", "Completed (On Hold)"])}
        {selectField("priorityLevel", "Priority", ["High", "Moderate", "Medium", "Low"])}
        {textField("dateOfSubmission", "Date of Submission")}
        {textField("deadline", "Deadline")}
        {textField("workStartDate", "Work Start")}
        {textField("completedDate", "Completed Date")}
        {selectWithOtherField("completedBy", "Assigned To", ASSIGNEES)}
        {textField("durationSpecs", "Duration/Specs")}
      </div>
      <div className="space-y-3 mt-3">
        {textField("projectBrief", "Project Brief", "textarea")}
        {textField("targetAudience", "Target Audience", "textarea")}
        {textField("keyMessage", "Key Message", "textarea")}
        {textField("referenceMoodBoard", "Reference/Mood Board", "textarea")}
      </div>
      <div className="grid grid-cols-3 gap-3 mt-3">
        {textField("scriptLink", "Script Link")}
        {textField("videoLink", "Video Link")}
        {textField("youtubeLink", "YouTube Link")}
      </div>
      {textField("notes", "Notes", "textarea")}
      <div className="flex gap-3 pt-4">
        <Button
          onClick={() => mutation.mutate(form as any)}
          disabled={mutation.isPending}
          className="flex-1 rounded-xl text-white font-semibold"
          style={{ background: "linear-gradient(135deg, #4a7cf7, #7c6ff7)" }}
          data-testid="button-save-edit"
        >
          {mutation.isPending ? "Saving…" : "Save Changes"}
        </Button>
        <Button variant="ghost" onClick={onClose} className="rounded-xl" data-testid="button-cancel-edit">
          Cancel
        </Button>
      </div>
    </DialogContent>
  );
}

// ─── Link chip ────────────────────────────────────────────────────────────────
// Always renders a visible chip. If the value is a proper URL (http/https),
// clicking opens it in a new tab. Otherwise it shows as a file/text label chip
// with a copy-on-click interaction.
function LinkChip({ href, label, color }: { href: string; label: string; color: string }) {
  const [copied, setCopied] = useState(false);
  const isUrl = href.startsWith("http://") || href.startsWith("https://");

  const handleClick = () => {
    if (isUrl) {
      window.open(href, "_blank", "noopener,noreferrer");
    } else {
      navigator.clipboard.writeText(href).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      });
    }
  };

  return (
    <button
      onClick={handleClick}
      title={copied ? "Copied!" : isUrl ? href : `Click to copy: ${href}`}
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium transition-all hover:opacity-80 active:scale-95 cursor-pointer"
      style={{ background: `${color}18`, color, border: `1px solid ${color}30`, textDecoration: "none" }}
    >
      {isUrl ? <ExternalLink size={10} /> : <FileText size={10} />}
      {copied ? "Copied!" : label}
    </button>
  );
}

// ─── Main Requests Page ───────────────────────────────────────────────────────
export default function Requests() {
  const { data: requests = [], isLoading } = useQuery<ContentRequest[]>({
    queryKey: ["/api/requests"],
    queryFn: () => apiRequest("GET", "/api/requests").then(r => r.json()),
    refetchInterval: 10000,
  });

  const qc = useQueryClient();
  const { toast } = useToast();

  const [showForm, setShowForm] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [priorityFilter, setPriorityFilter] = useState("All");
  const [requesterFilter, setRequesterFilter] = useState("All");
  const [editTarget, setEditTarget] = useState<ContentRequest | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ContentRequest | null>(null);
  const [sortKey, setSortKey] = useState<keyof ContentRequest>("requestId");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/requests/${id}`);
      if (!res.ok) throw new Error("Delete failed");
      return res;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/requests"] });
      toast({ title: "Deleted", description: "Request removed successfully." });
      setDeleteTarget(null);
    },
    onError: () => toast({ title: "Error", description: "Could not delete request.", variant: "destructive" }),
  });

  const filtered = useMemo(() => {
    return [...requests]
      .filter(r => {
        if (!search) return true;
        const q = search.toLowerCase();
        return [r.requestId, r.requestorName, r.projectTitle, r.contentType, r.status].some(v => v?.toLowerCase().includes(q));
      })
      .filter(r => statusFilter === "All" || r.status === statusFilter)
      .filter(r => priorityFilter === "All" || r.priorityLevel?.toLowerCase().trim() === priorityFilter.toLowerCase())
      .filter(r => requesterFilter === "All" || r.requestorName === requesterFilter)
      .sort((a, b) => {
        const av = (a[sortKey] as any) || "";
        const bv = (b[sortKey] as any) || "";
        const cmp = String(av).localeCompare(String(bv));
        return sortDir === "asc" ? cmp : -cmp;
      });
  }, [requests, search, statusFilter, priorityFilter, requesterFilter, sortKey, sortDir]);

  const handleSort = (key: keyof ContentRequest) => {
    if (sortKey === key) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortKey(key); setSortDir("asc"); }
  };

  const SortTh = ({ k, label }: { k: keyof ContentRequest; label: string }) => (
    <th
      className="text-left py-3 pr-3 font-semibold uppercase tracking-wider cursor-pointer select-none whitespace-nowrap hover:opacity-70 transition-opacity"
      style={{ color: "var(--text-muted)", fontSize: "10px" }}
      onClick={() => handleSort(k)}
    >
      {label} {sortKey === k ? (sortDir === "asc" ? "↑" : "↓") : ""}
    </th>
  );

  if (isLoading) return (
    <div className="flex items-center justify-center h-screen">
      <div className="w-8 h-8 rounded-full border-2 border-blue-400 border-t-transparent animate-spin" />
    </div>
  );

  return (
    <div className="p-6 space-y-4 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between fade-in">
        <div>
          <h1 className="text-xl font-bold gradient-text">All Requests</h1>
          <p className="text-sm mt-0.5" style={{ color: "var(--text-secondary)" }}>{filtered.length} of {requests.length} requests</p>
        </div>
        <button
          onClick={() => setShowForm(v => !v)}
          data-testid="button-toggle-form"
          className="flex items-center gap-2 h-9 px-4 rounded-xl text-white text-sm font-semibold transition-all hover:opacity-90 active:scale-95"
          style={{
            background: showForm ? "rgba(74,124,247,0.15)" : "linear-gradient(135deg, #4a7cf7, #7c6ff7)",
            border: showForm ? "1px solid rgba(74,124,247,0.3)" : "none",
            color: showForm ? "var(--accent-blue)" : "white",
            boxShadow: showForm ? "none" : "0 4px 16px rgba(74,124,247,0.35)",
          }}
        >
          {showForm ? <ChevronUp size={15} /> : <PlusCircle size={15} />}
          {showForm ? "Collapse Form" : "New Request"}
        </button>
      </div>

      {/* Inline new-request form shown by default */}
      {showForm && (
        <InlineNewRequest
          requests={requests}
          onSuccess={() => setShowForm(false)}
          onCancel={() => setShowForm(false)}
        />
      )}

      {/* Filters */}
      <div className="glass rounded-2xl p-4 border flex flex-wrap gap-3 items-center fade-in fade-in-delay-1">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "var(--text-muted)" }} />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by ID, name, project, type…"
            data-testid="input-search"
            className="w-full pl-9 pr-3 py-2 text-sm rounded-xl outline-none transition-all"
            style={{ background: "rgba(255,255,255,0.35)", border: "1px solid var(--glass-border)", color: "var(--text-primary)" }}
          />
        </div>

        {[
          { label: "Status", value: statusFilter, set: setStatusFilter, opts: STATUS_OPTIONS },
          { label: "Priority", value: priorityFilter, set: setPriorityFilter, opts: PRIORITY_OPTIONS },
          { label: "Requester", value: requesterFilter, set: setRequesterFilter, opts: REQUESTER_OPTIONS },
        ].map(({ label, value, set, opts }) => (
          <Select key={label} value={value} onValueChange={set}>
            <SelectTrigger
              className="w-[140px] text-sm rounded-xl"
              style={{ background: "rgba(255,255,255,0.35)", borderColor: "var(--glass-border)", color: "var(--text-primary)" }}
              data-testid={`select-${label.toLowerCase()}`}
            >
              <SlidersHorizontal size={12} className="mr-1.5" style={{ color: "var(--accent-blue)" }} />
              <SelectValue placeholder={label} />
            </SelectTrigger>
            <SelectContent className="glass-strong rounded-xl">
              {opts.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
            </SelectContent>
          </Select>
        ))}

        {(search || statusFilter !== "All" || priorityFilter !== "All" || requesterFilter !== "All") && (
          <button
            onClick={() => { setSearch(""); setStatusFilter("All"); setPriorityFilter("All"); setRequesterFilter("All"); }}
            className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-xl transition-all"
            style={{ background: "rgba(244,114,182,0.12)", color: "#db2777", border: "1px solid rgba(244,114,182,0.25)" }}
          >
            <X size={12} /> Clear
          </button>
        )}
      </div>

      {/* Table */}
      <div className="glass rounded-2xl border overflow-hidden fade-in fade-in-delay-2">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: "rgba(150,170,220,0.08)", borderBottom: "1px solid rgba(150,170,220,0.15)" }}>
                <th className="w-8 pl-4" />
                <SortTh k="requestId" label="ID" />
                <SortTh k="dateOfSubmission" label="Submitted" />
                <SortTh k="requestorName" label="Requestor" />
                <SortTh k="projectTitle" label="Project" />
                <SortTh k="contentType" label="Content Type" />
                <SortTh k="priorityLevel" label="Priority" />
                <SortTh k="status" label="Status" />
                <SortTh k="deadline" label="Deadline" />
                <SortTh k="completedBy" label="Assigned" />
                <th className="text-left py-3 pr-3 font-semibold uppercase tracking-wider whitespace-nowrap" style={{ color: "var(--text-muted)", fontSize: "10px" }}>Links</th>
                <th className="text-left py-3 pr-3 font-semibold uppercase tracking-wider" style={{ color: "var(--text-muted)", fontSize: "10px" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={12} className="py-16 text-center text-sm" style={{ color: "var(--text-muted)" }}>
                    No requests match your filters.
                  </td>
                </tr>
              ) : filtered.map((r, i) => (
                <tr
                  key={r.id}
                  data-testid={`row-request-${r.id}`}
                  className="transition-colors text-xs"
                  style={{ borderBottom: "1px solid rgba(150,170,220,0.08)" }}
                  onMouseEnter={e => (e.currentTarget.style.background = "rgba(150,170,220,0.06)")}
                  onMouseLeave={e => (e.currentTarget.style.background = "")}
                >
                  <td className="py-3 pl-4 text-center">
                    <span className="font-mono" style={{ color: "var(--text-muted)", fontSize: "11px" }}>{i + 1}</span>
                  </td>
                  <td className="py-3 pr-3 font-mono font-semibold whitespace-nowrap" style={{ color: "var(--accent-blue)", fontSize: "11px" }}>{r.requestId}</td>
                  <td className="py-3 pr-3 font-mono whitespace-nowrap" style={{ color: "var(--text-muted)", fontSize: "11px" }}>
                    {r.dateOfSubmission
                      ? new Date(r.dateOfSubmission).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "2-digit" })
                      : "—"}
                  </td>
                  <td className="py-3 pr-3 font-medium whitespace-nowrap" style={{ color: "var(--text-primary)" }}>{r.requestorName}</td>
                  <td className="py-3 pr-3 max-w-[150px]">
                    <span className="block truncate" style={{ color: "var(--text-secondary)" }} title={r.projectTitle || ""}>{r.projectTitle}</span>
                  </td>
                  <td className="py-3 pr-3 max-w-[140px]">
                    <span className="block truncate" style={{ color: "var(--text-muted)" }} title={r.contentType || ""}>{r.contentType}</span>
                  </td>
                  <td className="py-3 pr-3 whitespace-nowrap"><PriorityBadge priority={r.priorityLevel || "Medium"} /></td>
                  <td className="py-3 pr-3 whitespace-nowrap"><StatusBadge status={r.status || "Pending"} /></td>
                  <td className="py-3 pr-3 font-mono whitespace-nowrap" style={{ color: "var(--text-muted)", fontSize: "11px" }}>
                    {r.deadline ? new Date(r.deadline).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "2-digit" }) : "—"}
                  </td>
                  <td className="py-3 pr-3 whitespace-nowrap" style={{ color: "var(--text-secondary)" }}>{r.completedBy || "—"}</td>
                  {/* Links — always clickable chips */}
                  <td className="py-3 pr-3">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {r.scriptLink && <LinkChip href={r.scriptLink} label="Script" color="#7c3aed" />}
                      {r.videoLink && <LinkChip href={r.videoLink} label="Video" color="#2563eb" />}
                      {r.youtubeLink && <LinkChip href={r.youtubeLink} label="YouTube" color="#dc2626" />}
                      {!r.scriptLink && !r.videoLink && !r.youtubeLink && (
                        <span style={{ color: "var(--text-muted)" }}>—</span>
                      )}
                    </div>
                  </td>
                  <td className="py-3 pr-4">
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => setEditTarget(r)}
                        data-testid={`button-edit-${r.id}`}
                        className="w-7 h-7 rounded-lg flex items-center justify-center transition-all hover:opacity-80"
                        style={{ background: "rgba(74,124,247,0.1)", color: "#4a7cf7" }}
                        title="Edit"
                      >
                        <Edit2 size={12} />
                      </button>
                      <button
                        onClick={() => setDeleteTarget(r)}
                        data-testid={`button-delete-${r.id}`}
                        className="w-7 h-7 rounded-lg flex items-center justify-center transition-all hover:opacity-80"
                        style={{ background: "rgba(239,68,68,0.1)", color: "#dc2626" }}
                        title="Delete"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ─── Dashboard section below the table ─── */}
      <div className="pt-6">
        <div className="flex items-center gap-3 mb-5 fade-in">
          <div className="h-px flex-1" style={{ background: "rgba(150,170,220,0.2)" }} />
          <span className="text-xs font-semibold uppercase tracking-widest px-3" style={{ color: "var(--text-muted)" }}>Dashboard Overview</span>
          <div className="h-px flex-1" style={{ background: "rgba(150,170,220,0.2)" }} />
        </div>
        <DashboardContent />
      </div>

      {/* Edit dialog */}
      <Dialog open={!!editTarget} onOpenChange={o => !o && setEditTarget(null)}>
        {editTarget && <EditDialog request={editTarget} onClose={() => setEditTarget(null)} />}
      </Dialog>

      {/* Delete confirm dialog */}
      <Dialog open={!!deleteTarget} onOpenChange={o => !o && !deleteMutation.isPending && setDeleteTarget(null)}>
        {deleteTarget && (
          <DeleteConfirmDialog
            request={deleteTarget}
            onConfirm={() => deleteMutation.mutate(deleteTarget.id)}
            onCancel={() => setDeleteTarget(null)}
            isPending={deleteMutation.isPending}
          />
        )}
      </Dialog>
    </div>
  );
}
