import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { ContentRequest } from "@shared/schema";
import { useMemo, useEffect, useState } from "react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as ReTooltip,
  ResponsiveContainer, PieChart, Pie, Cell, RadialBarChart, RadialBar, Legend
} from "recharts";
import { CheckCircle2, Clock, Loader2, AlertCircle, TrendingUp, Film, Users, Zap, Calendar, Award, FolderOpen, TimerOff, Gauge } from "lucide-react";

// Animated counter hook
function useCountUp(target: number, duration = 1200) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (target === 0) return;
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) { setValue(target); clearInterval(timer); }
      else setValue(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [target, duration]);
  return value;
}

function KpiCard({ label, value, icon: Icon, colorClass, suffix = "", delay = 0 }: {
  label: string; value: number; icon: any; colorClass: string; suffix?: string; delay?: number;
}) {
  const counted = useCountUp(value);
  return (
    <div className={`glass rounded-2xl p-5 border hover-lift fade-in fade-in-delay-${delay} ${colorClass}`}>
      <div className="flex items-start justify-between mb-3">
        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: "var(--text-secondary)" }}>{label}</p>
        <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.3)" }}>
          <Icon size={15} strokeWidth={2.5} style={{ color: "var(--accent-blue)" }} />
        </div>
      </div>
      <p className="text-3xl font-bold count-up" style={{ color: "var(--text-primary)" }}>
        {counted}{suffix}
      </p>
    </div>
  );
}

const STATUS_COLORS: Record<string, string> = {
  "Completed": "#34d399",
  "Pending Production": "#a78bfa",
  "In Progress": "#60a5fa",
  "In Review": "#f59e0b",
  "Completed (On Hold)": "#f472b6",
  "Pending": "#fb923c",
};

const MONTH_ORDER = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

const REQUESTER_COLORS = ["#4a7cf7","#7c6ff7","#3bc9db","#f472b6","#34d399","#fb923c"];

export default function Dashboard() {
  const { data: requests = [], isLoading } = useQuery<ContentRequest[]>({
    queryKey: ["/api/requests"],
    queryFn: () => apiRequest("GET", "/api/requests").then((r) => r.json()),
    refetchInterval: 10000,
  });

  const stats = useMemo(() => {
    const total = requests.length;
    const completed = requests.filter(r => r.status === "Completed" || r.status === "Completed (On Hold)").length;
    const pending = requests.filter(r => r.status?.toLowerCase().includes("pending")).length;
    const inProgress = requests.filter(r => r.status === "In Progress").length;
    const rate = total > 0 ? Math.round((completed / total) * 100) : 0;
    const totalDuration = requests.reduce((s, r) => s + (r.durationMins || 0), 0);

    // Monthly breakdown
    const monthMap: Record<string, { total: number; completed: number }> = {};
    requests.forEach(r => {
      const d = r.deadline || r.dateOfSubmission;
      if (!d) return;
      const date = new Date(d);
      if (isNaN(date.getTime())) return;
      const key = `${MONTH_ORDER[date.getMonth()]} ${date.getFullYear()}`;
      if (!monthMap[key]) monthMap[key] = { total: 0, completed: 0 };
      monthMap[key].total++;
      if (r.status === "Completed" || r.status === "Completed (On Hold)") monthMap[key].completed++;
    });
    const monthlyData = Object.entries(monthMap)
      .sort(([a], [b]) => new Date("1 " + a).getTime() - new Date("1 " + b).getTime())
      .map(([month, v]) => ({ month: month.replace(" 2025", "").replace(" 2026", " '26"), ...v, pending: v.total - v.completed }));

    // Status breakdown for pie
    const statusMap: Record<string, number> = {};
    requests.forEach(r => {
      const s = r.status || "Unknown";
      statusMap[s] = (statusMap[s] || 0) + 1;
    });
    const statusData = Object.entries(statusMap).map(([name, value]) => ({ name, value, fill: STATUS_COLORS[name] || "#8a9aba" }));

    // Requester breakdown
    const reqMap: Record<string, { total: number; completed: number }> = {};
    requests.forEach(r => {
      const n = r.requestorName || "Unknown";
      if (!reqMap[n]) reqMap[n] = { total: 0, completed: 0 };
      reqMap[n].total++;
      if (r.status === "Completed" || r.status === "Completed (On Hold)") reqMap[n].completed++;
    });
    const requesterData = Object.entries(reqMap)
      .map(([name, v], i) => ({ name, ...v, fill: REQUESTER_COLORS[i % REQUESTER_COLORS.length], rate: Math.round((v.completed / v.total) * 100) }))
      .sort((a, b) => b.total - a.total);

    // Content type breakdown
    const typeMap: Record<string, number> = {};
    requests.forEach(r => {
      const t = r.contentType || "Other";
      typeMap[t] = (typeMap[t] || 0) + 1;
    });
    const topTypes = Object.entries(typeMap)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 6)
      .map(([name, value], i) => ({ name: name.length > 22 ? name.slice(0, 22) + "…" : name, value, fill: REQUESTER_COLORS[i % REQUESTER_COLORS.length] }));

    // Quarterly
    const quarterMap: Record<string, { total: number; completed: number }> = {
      "Q2 2025": { total: 0, completed: 0 },
      "Q3 2025": { total: 0, completed: 0 },
      "Q4 2025": { total: 0, completed: 0 },
      "Q1 2026": { total: 0, completed: 0 },
    };
    requests.forEach(r => {
      const d = r.deadline || r.dateOfSubmission;
      if (!d) return;
      const date = new Date(d);
      if (isNaN(date.getTime())) return;
      const y = date.getFullYear(), m = date.getMonth() + 1;
      let q = "";
      if (y === 2025) { if (m <= 3) q = "Q1 2025"; else if (m <= 6) q = "Q2 2025"; else if (m <= 9) q = "Q3 2025"; else q = "Q4 2025"; }
      else if (y === 2026) { if (m <= 3) q = "Q1 2026"; else if (m <= 6) q = "Q2 2026"; }
      if (q && quarterMap[q]) {
        quarterMap[q].total++;
        if (r.status === "Completed" || r.status === "Completed (On Hold)") quarterMap[q].completed++;
      }
    });
    const quarterData = Object.entries(quarterMap).map(([q, v]) => ({ q, ...v, rate: v.total > 0 ? Math.round((v.completed / v.total) * 100) : 0 }));

    // ─── Per-assignee workload (Vipin, Yeshveer, Neeta) ───────────────────────
    const ASSIGNEES = ["Vipin", "Yeshveer", "Neeta"] as const;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const workload = ASSIGNEES.map(name => {
      const mine = requests.filter(r => r.completedBy === name);
      const isClosedStatus = (s?: string | null) =>
        s === "Completed" || s === "Completed (On Hold)";

      const open = mine.filter(r => !isClosedStatus(r.status));
      const closedItems = mine.filter(r => isClosedStatus(r.status));

      // Overdue = open AND deadline < today AND deadline exists
      const overdue = open.filter(r => {
        if (!r.deadline) return false;
        const dl = new Date(r.deadline);
        return !isNaN(dl.getTime()) && dl < today;
      });

      // Avg turnaround: completed_date - work_start_date in days (only where both exist)
      const turnarounds: number[] = [];
      mine.forEach(r => {
        if (r.completedDate && r.workStartDate) {
          const s = new Date(r.workStartDate);
          const e = new Date(r.completedDate);
          if (!isNaN(s.getTime()) && !isNaN(e.getTime()) && e >= s) {
            turnarounds.push(Math.round((e.getTime() - s.getTime()) / 86400000));
          }
        }
      });
      const avgTurnaround = turnarounds.length
        ? Math.round(turnarounds.reduce((a, b) => a + b, 0) / turnarounds.length)
        : null;

      // Priority breakdown of open items
      const highOpen = open.filter(r => r.priorityLevel?.toLowerCase() === "high").length;

      // Completion rate
      const completionRate = mine.length > 0 ? Math.round((closedItems.length / mine.length) * 100) : 0;

      return { name, total: mine.length, open: open.length, closed: closedItems.length, overdue: overdue.length, avgTurnaround, completionRate, highOpen };
    });

    return { total, completed, pending, inProgress, rate, totalDuration, monthlyData, statusData, requesterData, topTypes, quarterData, workload };
  }, [requests]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="animate-spin" size={32} style={{ color: "var(--accent-blue)" }} />
          <p style={{ color: "var(--text-secondary)" }}>Loading dashboard…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between fade-in">
        <div>
          <h1 className="text-xl font-bold gradient-text">Content Operations</h1>
          <p className="text-sm mt-0.5" style={{ color: "var(--text-secondary)" }}>Live tracking dashboard · {requests.length} total requests</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="pulse-dot" />
          <span className="text-xs font-medium" style={{ color: "var(--text-secondary)" }}>Live</span>
        </div>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        <KpiCard label="Total" value={stats.total} icon={Film} colorClass="kpi-blue" delay={1} />
        <KpiCard label="Completed" value={stats.completed} icon={CheckCircle2} colorClass="kpi-teal" delay={2} />
        <KpiCard label="In Progress" value={stats.inProgress} icon={Loader2} colorClass="kpi-purple" delay={3} />
        <KpiCard label="Pending" value={stats.pending} icon={AlertCircle} colorClass="kpi-orange" delay={4} />
        <KpiCard label="Completion" value={stats.rate} icon={TrendingUp} colorClass="kpi-green" suffix="%" delay={5} />
        <KpiCard label="Total Mins" value={Math.round(stats.totalDuration)} icon={Zap} colorClass="kpi-rose" delay={5} />
      </div>

      {/* Row 2: Monthly area chart + Status pie */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Monthly trend */}
        <div className="glass rounded-2xl p-5 border lg:col-span-2 fade-in fade-in-delay-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Monthly Output</h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>Requests by deadline month</p>
            </div>
            <Calendar size={16} style={{ color: "var(--accent-blue)" }} />
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={stats.monthlyData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id="gradCompleted" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4a7cf7" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#4a7cf7" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradPending" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f472b6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#f472b6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(150,170,220,0.12)" />
              <XAxis dataKey="month" tick={{ fontSize: 10, fill: "var(--text-muted)" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "var(--text-muted)" }} axisLine={false} tickLine={false} allowDecimals={false} />
              <ReTooltip
                contentStyle={{ background: "var(--glass-bg-strong)", backdropFilter: "blur(16px)", border: "1px solid var(--glass-border)", borderRadius: "12px", fontSize: "12px" }}
                labelStyle={{ color: "var(--text-primary)", fontWeight: 600 }}
              />
              <Area type="monotone" dataKey="completed" name="Completed" stroke="#4a7cf7" strokeWidth={2} fill="url(#gradCompleted)" dot={false} />
              <Area type="monotone" dataKey="pending" name="Pending" stroke="#f472b6" strokeWidth={2} fill="url(#gradPending)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Status breakdown */}
        <div className="glass rounded-2xl p-5 border fade-in fade-in-delay-3">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Status Split</h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>Current state of all requests</p>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <ResponsiveContainer width="100%" height={140}>
              <PieChart>
                <Pie
                  data={stats.statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={42}
                  outerRadius={62}
                  paddingAngle={3}
                  dataKey="value"
                  strokeWidth={0}
                >
                  {stats.statusData.map((entry, index) => (
                    <Cell key={index} fill={entry.fill} />
                  ))}
                </Pie>
                <ReTooltip contentStyle={{ background: "var(--glass-bg-strong)", backdropFilter: "blur(16px)", border: "1px solid var(--glass-border)", borderRadius: "12px", fontSize: "12px" }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-1.5 mt-2">
            {stats.statusData.map((s, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: s.fill }} />
                  <span className="text-xs truncate max-w-[120px]" style={{ color: "var(--text-secondary)" }}>{s.name}</span>
                </div>
                <span className="text-xs font-semibold" style={{ color: "var(--text-primary)" }}>{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ─── Workload Summary Panel ─── */}
      <div className="fade-in fade-in-delay-3">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex items-center gap-2">
            <Gauge size={15} style={{ color: "var(--accent-blue)" }} />
            <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Team Workload</h2>
          </div>
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>Open requests, turnaround time & overdue items per assignee</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {stats.workload.map((w, i) => {
            const PALETTE = [
              { accent: "#4a7cf7", bg: "rgba(74,124,247,0.08)", ring: "rgba(74,124,247,0.25)", avatarBg: "linear-gradient(135deg, #4a7cf7, #7c6ff7)" },
              { accent: "#3bc9db", bg: "rgba(59,201,219,0.08)", ring: "rgba(59,201,219,0.25)", avatarBg: "linear-gradient(135deg, #3bc9db, #4a7cf7)" },
              { accent: "#f472b6", bg: "rgba(244,114,182,0.08)", ring: "rgba(244,114,182,0.25)", avatarBg: "linear-gradient(135deg, #f472b6, #a78bfa)" },
            ];
            const pal = PALETTE[i];
            const isAvailable = w.total === 0;
            return (
              <div
                key={w.name}
                className="glass rounded-2xl border hover-lift"
                style={{ borderColor: "var(--glass-border)", overflow: "hidden" }}
              >
                {/* Card header */}
                <div className="px-5 pt-5 pb-4" style={{ borderBottom: "1px solid rgba(150,170,220,0.1)" }}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
                        style={{ background: pal.avatarBg, boxShadow: `0 4px 12px ${pal.ring}` }}
                      >
                        {w.name[0]}
                      </div>
                      <div>
                        <p className="text-sm font-bold" style={{ color: "var(--text-primary)" }}>{w.name}</p>
                        <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                          {isAvailable ? "No assignments yet" : `${w.total} total · ${w.completionRate}% done`}
                        </p>
                      </div>
                    </div>
                    {/* Status pill */}
                    {w.overdue > 0 ? (
                      <span className="text-xs font-semibold px-2.5 py-1 rounded-full" style={{ background: "rgba(239,68,68,0.12)", color: "#dc2626" }}>
                        {w.overdue} overdue
                      </span>
                    ) : isAvailable ? (
                      <span className="text-xs font-semibold px-2.5 py-1 rounded-full" style={{ background: "rgba(59,201,219,0.12)", color: "#0891b2" }}>
                        Available
                      </span>
                    ) : (
                      <span className="text-xs font-semibold px-2.5 py-1 rounded-full" style={{ background: "rgba(52,211,153,0.12)", color: "#059669" }}>
                        On track
                      </span>
                    )}
                  </div>

                  {/* Completion progress bar */}
                  {!isAvailable && (
                    <div className="mt-3">
                      <div className="h-1.5 rounded-full" style={{ background: "rgba(150,170,220,0.15)" }}>
                        <div
                          className="h-1.5 rounded-full transition-all duration-1000"
                          style={{ width: `${w.completionRate}%`, background: pal.accent }}
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Stat grid */}
                <div className="grid grid-cols-3 divide-x" style={{ divideColor: "rgba(150,170,220,0.1)" }}>
                  {/* Open */}
                  <div className="px-4 py-4 text-center">
                    <div className="flex items-center justify-center gap-1 mb-1.5">
                      <FolderOpen size={12} style={{ color: pal.accent }} />
                      <span className="text-xs font-medium uppercase tracking-wider" style={{ color: "var(--text-muted)", fontSize: "9px" }}>Open</span>
                    </div>
                    <p
                      className="text-2xl font-bold"
                      style={{ color: w.open > 0 ? pal.accent : "var(--text-muted)" }}
                    >
                      {w.open}
                    </p>
                    {w.highOpen > 0 && (
                      <p className="text-xs mt-0.5" style={{ color: "#f97316", fontSize: "10px" }}>{w.highOpen} high pri</p>
                    )}
                  </div>

                  {/* Avg turnaround */}
                  <div className="px-4 py-4 text-center">
                    <div className="flex items-center justify-center gap-1 mb-1.5">
                      <Clock size={12} style={{ color: pal.accent }} />
                      <span className="text-xs font-medium uppercase tracking-wider" style={{ color: "var(--text-muted)", fontSize: "9px" }}>Avg Days</span>
                    </div>
                    <p className="text-2xl font-bold" style={{ color: "var(--text-primary)" }}>
                      {w.avgTurnaround !== null ? w.avgTurnaround : "—"}
                    </p>
                    {w.avgTurnaround !== null && (
                      <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)", fontSize: "10px" }}>turnaround</p>
                    )}
                  </div>

                  {/* Overdue */}
                  <div className="px-4 py-4 text-center">
                    <div className="flex items-center justify-center gap-1 mb-1.5">
                      <TimerOff size={12} style={{ color: w.overdue > 0 ? "#dc2626" : pal.accent }} />
                      <span className="text-xs font-medium uppercase tracking-wider" style={{ color: "var(--text-muted)", fontSize: "9px" }}>Overdue</span>
                    </div>
                    <p
                      className="text-2xl font-bold"
                      style={{ color: w.overdue > 0 ? "#dc2626" : "var(--text-muted)" }}
                    >
                      {w.overdue}
                    </p>
                    {w.overdue === 0 && !isAvailable && (
                      <p className="text-xs mt-0.5" style={{ color: "#059669", fontSize: "10px" }}>all clear</p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Row 3: Requester bar + Quarterly + Content types */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Requester performance */}
        <div className="glass rounded-2xl p-5 border fade-in fade-in-delay-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>By Requester</h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>Requests per team member</p>
            </div>
            <Users size={15} style={{ color: "var(--accent-purple)" }} />
          </div>
          <div className="space-y-3">
            {stats.requesterData.map((r, i) => (
              <div key={r.name}>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                      style={{ background: r.fill }}>
                      {r.name[0]}
                    </div>
                    <span className="text-xs font-medium" style={{ color: "var(--text-primary)" }}>{r.name}</span>
                  </div>
                  <span className="text-xs font-semibold" style={{ color: "var(--text-secondary)" }}>{r.total} · {r.rate}%</span>
                </div>
                <div className="h-1.5 rounded-full" style={{ background: "rgba(150,170,220,0.15)" }}>
                  <div className="h-1.5 rounded-full transition-all duration-1000" style={{ width: `${r.rate}%`, background: r.fill }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quarterly */}
        <div className="glass rounded-2xl p-5 border fade-in fade-in-delay-3">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Quarterly View</h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>Q2 2025 – Q1 2026</p>
            </div>
            <Award size={15} style={{ color: "var(--accent-teal)" }} />
          </div>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={stats.quarterData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(150,170,220,0.12)" />
              <XAxis dataKey="q" tick={{ fontSize: 10, fill: "var(--text-muted)" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "var(--text-muted)" }} axisLine={false} tickLine={false} allowDecimals={false} />
              <ReTooltip contentStyle={{ background: "var(--glass-bg-strong)", backdropFilter: "blur(16px)", border: "1px solid var(--glass-border)", borderRadius: "12px", fontSize: "12px" }} />
              <Bar dataKey="completed" name="Completed" fill="#4a7cf7" radius={[4, 4, 0, 0]} />
              <Bar dataKey="total" name="Total" fill="rgba(74,124,247,0.2)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Top content types */}
        <div className="glass rounded-2xl p-5 border fade-in fade-in-delay-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Content Types</h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>Top 6 most requested</p>
            </div>
            <Film size={15} style={{ color: "var(--accent-rose)" }} />
          </div>
          <div className="space-y-2.5">
            {stats.topTypes.map((t, i) => (
              <div key={t.name}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs truncate max-w-[150px]" style={{ color: "var(--text-secondary)" }}>{t.name}</span>
                  <span className="text-xs font-bold" style={{ color: "var(--text-primary)" }}>{t.value}</span>
                </div>
                <div className="h-1.5 rounded-full" style={{ background: "rgba(150,170,220,0.15)" }}>
                  <div className="h-1.5 rounded-full" style={{ width: `${(t.value / stats.total) * 100}%`, background: t.fill }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Row 4: Recent activity */}
      <div className="glass rounded-2xl p-5 border fade-in fade-in-delay-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Recent Requests</h2>
            <p className="text-xs" style={{ color: "var(--text-muted)" }}>Last 6 submitted</p>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr style={{ borderBottom: "1px solid rgba(150,170,220,0.15)" }}>
                {["ID", "Requestor", "Project", "Type", "Priority", "Status", "Deadline"].map(h => (
                  <th key={h} className="text-left pb-2 pr-4 font-semibold uppercase tracking-wider" style={{ color: "var(--text-muted)", fontSize: "10px" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[...requests].reverse().slice(0, 6).map((r, i) => (
                <tr key={r.id} className="border-b transition-colors" style={{ borderColor: "rgba(150,170,220,0.08)" }}>
                  <td className="py-2.5 pr-4 font-mono font-semibold" style={{ color: "var(--accent-blue)", fontSize: "11px" }}>{r.requestId}</td>
                  <td className="py-2.5 pr-4 font-medium" style={{ color: "var(--text-primary)" }}>{r.requestorName}</td>
                  <td className="py-2.5 pr-4 max-w-[160px] truncate" style={{ color: "var(--text-secondary)" }}>{r.contentType}</td>
                  <td className="py-2.5 pr-4 max-w-[120px] truncate" style={{ color: "var(--text-secondary)" }}>{r.contentType}</td>
                  <td className="py-2.5 pr-4">
                    <PriorityBadge priority={r.priorityLevel || "Medium"} />
                  </td>
                  <td className="py-2.5 pr-4">
                    <StatusBadge status={r.status || "Pending"} />
                  </td>
                  <td className="py-2.5 font-mono text-xs" style={{ color: "var(--text-muted)" }}>
                    {r.deadline ? new Date(r.deadline).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "2-digit" }) : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const s = status.toLowerCase();
  let cls = "badge-pending";
  if (s === "completed") cls = "badge-completed";
  else if (s.includes("on hold")) cls = "badge-onhold";
  else if (s === "in progress") cls = "badge-progress";
  else if (s.includes("pending production")) cls = "badge-production";
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${cls}`}>
      {status}
    </span>
  );
}

export function PriorityBadge({ priority }: { priority: string }) {
  const p = priority.toLowerCase().trim();
  let cls = "priority-medium";
  if (p === "high") cls = "priority-high";
  else if (p === "low") cls = "priority-low";
  else if (p === "moderate") cls = "priority-moderate";
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${cls}`}>
      {priority}
    </span>
  );
}
