import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import * as schema from "@shared/schema";
import path from "path";

// Use DATA_DIR env var so Railway can point to a persistent volume.
// Falls back to current working directory for local development.
const dbDir = process.env.DATA_DIR || process.cwd();
const sqlite = new Database(path.join(dbDir, "data.db"));
export const db = drizzle(sqlite, { schema });

// Ensure tables exist
sqlite.exec(`
  CREATE TABLE IF NOT EXISTS content_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT NOT NULL UNIQUE,
    requestor_name TEXT NOT NULL,
    project_title TEXT NOT NULL,
    content_type TEXT NOT NULL,
    quantity INTEGER DEFAULT 1,
    project_brief TEXT,
    reference_mood_board TEXT,
    target_audience TEXT,
    key_message TEXT,
    date_of_submission TEXT,
    work_start_date TEXT,
    completed_date TEXT,
    deadline TEXT,
    duration_specs TEXT,
    duration_mins REAL,
    priority_level TEXT DEFAULT 'High',
    status TEXT DEFAULT 'Pending',
    completed_by TEXT,
    script_link TEXT,
    video_link TEXT,
    youtube_link TEXT,
    notes TEXT,
    created_at TEXT,
    updated_at TEXT
  )
`);
