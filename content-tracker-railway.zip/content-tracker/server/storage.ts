import { db } from "./db";
import { contentRequests, type ContentRequest, type InsertContentRequest } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getAllRequests(): ContentRequest[];
  getRequestById(id: number): ContentRequest | undefined;
  createRequest(data: InsertContentRequest): ContentRequest;
  updateRequest(id: number, data: Partial<InsertContentRequest>): ContentRequest | undefined;
  deleteRequest(id: number): boolean;
  seedIfEmpty(): void;
}

export class DatabaseStorage implements IStorage {
  getAllRequests(): ContentRequest[] {
    return db.select().from(contentRequests).all();
  }

  getRequestById(id: number): ContentRequest | undefined {
    return db.select().from(contentRequests).where(eq(contentRequests.id, id)).get();
  }

  createRequest(data: InsertContentRequest): ContentRequest {
    const now = new Date().toISOString();
    return db.insert(contentRequests).values({
      ...data,
      createdAt: now,
      updatedAt: now,
    }).returning().get();
  }

  updateRequest(id: number, data: Partial<InsertContentRequest>): ContentRequest | undefined {
    const now = new Date().toISOString();
    const result = db.update(contentRequests)
      .set({ ...data, updatedAt: now })
      .where(eq(contentRequests.id, id))
      .returning()
      .get();
    return result;
  }

  deleteRequest(id: number): boolean {
    const result = db.delete(contentRequests).where(eq(contentRequests.id, id)).run();
    return result.changes > 0;
  }

  seedIfEmpty(): void {
    const existing = db.select().from(contentRequests).all();
    if (existing.length > 0) return;

    const seedData: InsertContentRequest[] = [
      { requestId: "CCR-001", requestorName: "Vipin", projectTitle: "Sanjay Pal AI Video", contentType: "AI Video Fixes", quantity: 1, dateOfSubmission: "2025-07-28", workStartDate: "2025-07-28", completedDate: "2025-07-28", deadline: "2025-07-28", priorityLevel: "Medium", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-002", requestorName: "Shubhra", projectTitle: "Corporate Video", contentType: "Social Media Promotion", quantity: 1, dateOfSubmission: "2025-07-28", workStartDate: "2025-07-28", completedDate: "2025-07-28", deadline: "2025-07-30", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-003", requestorName: "Shubhra", projectTitle: "Explainer Video", contentType: "Eximius Explainer Video", quantity: 1, dateOfSubmission: "2025-04-06", workStartDate: "2025-04-06", completedDate: "2025-04-09", deadline: "2025-04-09", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-004", requestorName: "Shubhra", projectTitle: "For Orientation", contentType: "Immigration Orientation", quantity: 1, dateOfSubmission: "2025-09-07", workStartDate: "2025-09-07", completedDate: "2025-09-09", deadline: "2025-09-09", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-005", requestorName: "Shubhra", projectTitle: "For Promotion", contentType: "Cybersecurity Main Video", quantity: 1, dateOfSubmission: "2025-09-08", workStartDate: "2025-09-08", completedDate: "2025-08-09", deadline: "2025-08-09", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-006", requestorName: "Abhyuday", projectTitle: "Eximius Product Promo", contentType: "Eximius Product Promo", quantity: 1, dateOfSubmission: "2025-09-13", workStartDate: "2025-09-13", completedDate: "2025-09-18", deadline: "2025-09-18", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-007", requestorName: "Shubhra", projectTitle: "Eximius Teaser", contentType: "Eximius Teaser - 1", quantity: 1, dateOfSubmission: "2025-12-09", workStartDate: "2025-12-09", completedDate: "2025-12-09", deadline: "2025-12-09", priorityLevel: "High", status: "Completed (On Hold)", completedBy: "Vipin" },
      { requestId: "CCR-008", requestorName: "Ruchita", projectTitle: "Lead Gen", contentType: "Cybersecurity Lead Gen Video", quantity: 1, dateOfSubmission: "2025-09-15", workStartDate: "2025-09-15", completedDate: "2025-09-19", deadline: "2025-09-19", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-009", requestorName: "Abhyuday", projectTitle: "Topic Video", contentType: "Video 1 - Eximius From Vacancy to Value", quantity: 1, dateOfSubmission: "2025-09-27", workStartDate: "2025-09-27", completedDate: "2025-09-29", deadline: "2025-09-29", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-010", requestorName: "Abhyuday", projectTitle: "Topic Video", contentType: "Video 2 - Eximius Empowering Recruiters", quantity: 1, dateOfSubmission: "2025-09-27", workStartDate: "2025-09-27", completedDate: "2025-09-29", deadline: "2025-09-29", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-011", requestorName: "Abhyuday", projectTitle: "Topic Video", contentType: "Video 3 - Eximius_Kickstart 2026 Talent Strategy", quantity: 1, dateOfSubmission: "2025-09-27", workStartDate: "2025-09-27", completedDate: "2025-09-29", deadline: "2025-09-29", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-012", requestorName: "Shubhra", projectTitle: "Product Walkthrough", contentType: "Eximius Explainer Video", quantity: 1, dateOfSubmission: "2025-08-05", workStartDate: "2025-08-05", completedDate: "2025-08-10", deadline: "2025-08-10", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-013", requestorName: "Abhyuday", projectTitle: "Referral Video", contentType: "Eximius Referral Program", quantity: 1, dateOfSubmission: "2025-10-11", workStartDate: "2025-10-11", completedDate: "2025-10-14", deadline: "2025-10-14", priorityLevel: "High", status: "Completed (On Hold)", completedBy: "Vipin" },
      { requestId: "CCR-014", requestorName: "Abhyuday", projectTitle: "SaaS Lead Gen", contentType: "Eximius Lead Gen", quantity: 1, dateOfSubmission: "2025-10-07", workStartDate: "2025-10-07", completedDate: "2025-10-10", deadline: "2025-10-10", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-015", requestorName: "Shubhra", projectTitle: "SaaS Explainer Video", contentType: "Fast Hiring Video (HD & REEL FORMAT)", quantity: 1, dateOfSubmission: "2025-10-09", workStartDate: "2025-10-09", completedDate: "2025-10-13", deadline: "2025-10-13", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-016", requestorName: "Abhyuday", projectTitle: "SaaS Explainer Video", contentType: "Effortless AI Hiring (HD & REEL FORMAT)", quantity: 1, dateOfSubmission: "2025-10-09", workStartDate: "2025-10-09", completedDate: "2025-10-14", deadline: "2025-10-14", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-017", requestorName: "Ruchita", projectTitle: "Service Video", contentType: "CyberSecurity Service Video (HD & REEL FORMAT)", quantity: 1, dateOfSubmission: "2025-10-20", workStartDate: "2025-10-20", completedDate: "2025-10-24", deadline: "2025-10-24", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-018", requestorName: "Shubhra", projectTitle: "Logo Animation", contentType: "Eximius Logo Animation", quantity: 1, dateOfSubmission: "2025-10-27", workStartDate: "2025-10-27", completedDate: "2025-10-27", deadline: "2025-10-27", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-019", requestorName: "Abhyuday", projectTitle: "Interactive Video", contentType: "Eximius Interactive Video", quantity: 1, dateOfSubmission: "2025-11-08", workStartDate: "2025-11-08", completedDate: "2025-11-11", deadline: "2025-11-11", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-020", requestorName: "Abhyuday", projectTitle: "Category Specific Video", contentType: "Final Indi Recruiter Video (Updated)", quantity: 1, dateOfSubmission: "2025-11-15", workStartDate: "2025-11-15", completedDate: "2025-11-18", deadline: "2025-11-18", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-021", requestorName: "Abhyuday", projectTitle: "How to Feature Videos", contentType: "6 Feature Specific Videos", quantity: 1, dateOfSubmission: "2025-10-07", workStartDate: "2025-10-07", completedDate: "2025-10-11", deadline: "2025-10-11", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-022", requestorName: "Ruchita", projectTitle: "Referral Video", contentType: "Compunnel Referral Video", quantity: 1, dateOfSubmission: "2025-12-05", workStartDate: "2025-12-05", completedDate: "2025-12-11", deadline: "2025-12-11", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-023", requestorName: "Abhyuday", projectTitle: "Theme Based Promotion Video", contentType: "Eximius For Agencies", quantity: 1, dateOfSubmission: "2025-11-12", workStartDate: "2025-11-12", completedDate: "2025-11-14", deadline: "2025-11-14", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-024", requestorName: "Abhyuday", projectTitle: "Theme Based Promotion Video", contentType: "Eximius For Startups", quantity: 1, dateOfSubmission: "2025-11-12", workStartDate: "2025-11-12", completedDate: "2025-11-15", deadline: "2025-11-15", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-025", requestorName: "Abhyuday", projectTitle: "Theme Based Promotion Video", contentType: "Eximius For Independent Recruiters", quantity: 1, dateOfSubmission: "2025-11-12", workStartDate: "2025-11-11", completedDate: "2025-11-14", deadline: "2025-11-14", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-026", requestorName: "Abhyuday", projectTitle: "Category Specific Video", contentType: "Eximius For Businesses (Updated)", quantity: 1, dateOfSubmission: "2025-11-15", workStartDate: "2025-11-15", completedDate: "2025-11-18", deadline: "2025-11-18", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-027", requestorName: "Abhyuday", projectTitle: "Social Media Post", contentType: "Eximius Social Media Post", quantity: 1, dateOfSubmission: "2025-11-24", workStartDate: "2025-11-24", completedDate: "2025-11-24", deadline: "2025-11-24", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-028", requestorName: "Ruchita", projectTitle: "Informational", contentType: "Cybersecurity Report", quantity: 1, dateOfSubmission: "2026-01-02", workStartDate: "2026-01-02", completedDate: "2026-01-08", deadline: "2026-01-09", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-029", requestorName: "Ruchita", projectTitle: "Informational", contentType: "Cybersecurity Report Reel", quantity: 1, dateOfSubmission: "2026-01-02", workStartDate: "2026-01-02", completedDate: "2026-01-08", deadline: "2026-01-09", priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-030", requestorName: "Abhishek", projectTitle: "Eximius Podcast EP - 1", contentType: "Video visual of podcast", quantity: 1, projectBrief: "The content is a discussion about the problem of Ghost jobs that candidates face these days and implicitly introduces eximius as a solution.", targetAudience: "Enterprise Recruiters", keyMessage: "Eximius is helping not just recruiters but creating a better experience for candidates", dateOfSubmission: "2026-01-08", workStartDate: "2026-01-08", completedDate: "2026-01-09", deadline: "2026-01-09", durationSpecs: "11 minutes", durationMins: 11, priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-031", requestorName: "Ruchita", projectTitle: "EOR Services Promotional Video", contentType: "Promotional Video", quantity: 1, projectBrief: "The content is about EOR services of Compunnel", targetAudience: "Mid Segment US & UK Companies", dateOfSubmission: "2026-02-18", workStartDate: "2026-02-18", completedDate: "2026-02-23", deadline: "2026-02-23", durationSpecs: "1.20 Minutes", durationMins: 1.2, priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-032", requestorName: "Shubhra", projectTitle: "Eximius Platform Demo", contentType: "Explainer Video", quantity: 1, projectBrief: "Eximius Features Highlight", targetAudience: "Enterprise Recruiters", dateOfSubmission: "2026-02-13", workStartDate: "2026-02-13", completedDate: "2026-02-16", deadline: "2026-02-16", durationSpecs: "1.44 Minutes", durationMins: 1.44, priorityLevel: "High", status: "Completed", completedBy: "Vipin" },
      { requestId: "CCR-033", requestorName: "Abhyuday", projectTitle: "Resume Overload Problem Film", contentType: "Website Video", quantity: 1, projectBrief: "Create an emotionally compelling awareness video that highlights the chaos recruiters face due to resume overload. The video should visually and emotionally depict the pain of manual screening and transition sharply into a moment of clarity powered by AI-driven candidate matching.", referenceMoodBoard: "Slack/Notion brand films, Apple-style minimal storytelling, Fast-cut chaos sequences", targetAudience: "Primary: Recruiters, Talent Acquisition Teams; Secondary: HR Leaders, Hiring Managers", keyMessage: "Resume overload isn't a productivity problem — it's a system problem. Eximius transforms chaotic resume screening into intelligent, instant candidate matching.", dateOfSubmission: "2026-04-01", durationSpecs: "45–60 seconds", durationMins: 0.43, priorityLevel: "High", status: "Pending Production", completedBy: "Vipin", scriptLink: "Video2 - Resume Overload Challenge.docx" },
      { requestId: "CCR-034", requestorName: "Abhyuday", projectTitle: "3 Roles. 7 Days. Watch AI Hire.", contentType: "Conversion Video", quantity: 1, projectBrief: "Create a high-conversion, challenge-style video that invites businesses to test Eximius through a pilot.", referenceMoodBoard: "Performance marketing SaaS ads (HubSpot, Notion growth ads), Challenge-based startup campaigns", targetAudience: "Primary: HR Leaders, TA Heads; Secondary: Founders, Hiring Managers", keyMessage: "Don't just evaluate AI hiring — try it for FREE. Run a pilot with 3 roles and see results in 7 days.", dateOfSubmission: "2026-04-01", durationSpecs: "45–60 seconds", durationMins: 0.43, priorityLevel: "High", status: "Pending Production", completedBy: "Vipin", scriptLink: "Video3 - 3 Roles. 7 Days. Watch AI Hire..docx" },
      { requestId: "CCR-035", requestorName: "Ruchita", projectTitle: "Cybersecurity IAM Services", contentType: "Promotional Video", quantity: 1, projectBrief: "Create a high-impact, conversion-focused video showcasing Cybersecurity IAM (Identity & Access Management) services.", targetAudience: "Primary: CIOs, CISOs, IT Security Heads; Secondary: CTOs, Compliance Officers", keyMessage: "Don't let identity be your weakest link. Secure every access point with IAM.", dateOfSubmission: "2026-04-03", priorityLevel: "Medium", status: "Pending Production", completedBy: "Vipin", scriptLink: "Compunnel_IAM_Scripts.xlsx" },
      { requestId: "CCR-036", requestorName: "Ruchita", projectTitle: "Cybersecurity Data Security Services", contentType: "Promotional Video", quantity: 1, projectBrief: "Create a high-impact, conversion-focused video showcasing Data Security & DSPM services.", targetAudience: "Primary: CISOs, CDOs, IT Security Leaders; Secondary: CTOs, Compliance & Risk Officers", keyMessage: "You can't protect what you can't see. Gain full visibility and control over your data.", priorityLevel: "Medium", status: "Pending Production", completedBy: "Vipin" },
      { requestId: "CCR-037", requestorName: "Shubhra", projectTitle: "Cinematic Advert", contentType: "Cinematic Advert", quantity: 1, projectBrief: "A cinematic commercial concept built entirely with an AI-assisted production pipeline. Dark comedic tone featuring 'The Nerd' character.", targetAudience: "Primary: Recruiters, Talent Acquisition Teams; Secondary: HR Leaders, Hiring Managers", dateOfSubmission: "2025-12-19", workStartDate: "2025-12-19", completedDate: "2025-12-29", deadline: "2025-12-29", durationSpecs: "2.10 Minutes", priorityLevel: "High", status: "Completed", completedBy: "Vipin", videoLink: "Cinematic Advert" },
      { requestId: "CCR-038", requestorName: "Shubhra", projectTitle: "The Compunnel Song", contentType: "Promotional Video", quantity: 1, projectBrief: "A culture video that should inspire people", keyMessage: "It should reflect a positive and energetic atmosphere that inspires people to feel proud of their organization.", dateOfSubmission: "2026-01-29", workStartDate: "2026-02-05", completedDate: "2026-02-05", deadline: "2026-02-27", durationSpecs: "1.40 Minutes", priorityLevel: "Moderate", status: "Completed", completedBy: "Vipin" },
    ];

    for (const item of seedData) {
      const now = new Date().toISOString();
      db.insert(contentRequests).values({ ...item, createdAt: now, updatedAt: now }).run();
    }
  }
}

export const storage = new DatabaseStorage();
