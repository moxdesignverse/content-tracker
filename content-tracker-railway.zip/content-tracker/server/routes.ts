import type { Express } from "express";
import { type Server } from "http";
import { storage } from "./storage";
import { insertContentRequestSchema } from "@shared/schema";

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  // Seed database on startup
  storage.seedIfEmpty();

  // GET all requests
  app.get("/api/requests", (_req, res) => {
    try {
      const requests = storage.getAllRequests();
      res.json(requests);
    } catch (e) {
      res.status(500).json({ error: "Failed to fetch requests" });
    }
  });

  // GET single request
  app.get("/api/requests/:id", (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
    const request = storage.getRequestById(id);
    if (!request) return res.status(404).json({ error: "Not found" });
    res.json(request);
  });

  // POST create new request
  app.post("/api/requests", (req, res) => {
    try {
      const parsed = insertContentRequestSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.flatten() });
      }
      const created = storage.createRequest(parsed.data);
      res.status(201).json(created);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // PATCH update request
  app.patch("/api/requests/:id", (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
    try {
      const partial = insertContentRequestSchema.partial().safeParse(req.body);
      if (!partial.success) {
        return res.status(400).json({ error: partial.error.flatten() });
      }
      const updated = storage.updateRequest(id, partial.data);
      if (!updated) return res.status(404).json({ error: "Not found" });
      res.json(updated);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // DELETE request
  app.delete("/api/requests/:id", (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
    const deleted = storage.deleteRequest(id);
    if (!deleted) return res.status(404).json({ error: "Not found" });
    res.json({ success: true });
  });

  return httpServer;
}
