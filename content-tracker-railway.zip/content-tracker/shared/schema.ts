import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const contentRequests = sqliteTable("content_requests", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  requestId: text("request_id").notNull().unique(), // CCR-001 etc.
  requestorName: text("requestor_name").notNull(),
  projectTitle: text("project_title").notNull(),
  contentType: text("content_type").notNull(),
  quantity: integer("quantity").default(1),
  projectBrief: text("project_brief"),
  referenceMoodBoard: text("reference_mood_board"),
  targetAudience: text("target_audience"),
  keyMessage: text("key_message"),
  dateOfSubmission: text("date_of_submission"),
  workStartDate: text("work_start_date"),
  completedDate: text("completed_date"),
  deadline: text("deadline"),
  durationSpecs: text("duration_specs"),
  durationMins: real("duration_mins"),
  priorityLevel: text("priority_level").default("High"), // High / Medium / Low
  status: text("status").default("Pending"), // Pending / In Progress / In Review / Pending Production / Completed / Completed (On Hold)
  completedBy: text("completed_by"),
  scriptLink: text("script_link"),
  videoLink: text("video_link"),
  youtubeLink: text("youtube_link"),
  notes: text("notes"),
  createdAt: text("created_at"),
  updatedAt: text("updated_at"),
});

export const insertContentRequestSchema = createInsertSchema(contentRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertContentRequest = z.infer<typeof insertContentRequestSchema>;
export type ContentRequest = typeof contentRequests.$inferSelect;
